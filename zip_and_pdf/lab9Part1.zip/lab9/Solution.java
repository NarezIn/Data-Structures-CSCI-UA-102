package lab9;

import java.io.*;
import java.util.*;
 
public class Solution {

    public static int solution(int[] nums, int k){
        
        //******************** Write your code here ********************//
        PriorityQueue<Integer> pq = new PriorityQueue<>();
        for(int i = 0; i < nums.length; i++){
            pq.add(nums[i]);
        }
        int item = 0;
        System.out.println(pq);
        for(int j = nums.length - k ; j > -1; j--){
            item = pq.poll();
        }
        return item;
        //**************************************************************//

    }

}
