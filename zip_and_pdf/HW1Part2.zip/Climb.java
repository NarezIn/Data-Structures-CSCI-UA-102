package hw1;
import java.util.Scanner;

public class Climb {

    static int climbStairs(int n){
        // ------------------- //
        // Implement this part //
        if(n == 1 || n == 2){
            return n;
        }
        return climbStairs(n - 2) + climbStairs(n - 1);
        // ------------------- //
    }

    public static void main(String[] args) {
        // ----------------------------------- //
        // You don't need to correct this part //
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter an integer between 0 and 45: ");

        int n = scanner.nextInt();

        int result = climbStairs(n);
        System.out.println(result);

        scanner.close();
        // ----------------------------------- //
    }
}

