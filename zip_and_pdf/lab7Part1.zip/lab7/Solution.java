package lab7;

import java.io.*;
import java.util.*;
 
public class Solution {

    public static String solution(int[] nums){
        //******************** Write your code here ********************//
        int curr, j, temp;
        for(int i = 1; i < nums.length; i++){
            curr = nums[i];
            j = i - 1;
            while(toSwap(nums[j], nums[j+1]) && j >= 0){
                //swap
                temp = nums[j+1];
                nums[j+1] = nums[j];
                nums[j] = temp;
                j--;
                if(j == -1){
                    break;
                }
            }
            nums[j+1] = curr;
        }
        if(nums[0] == 0){
            return "0";
        }
        else {
            String builder = "";
            for (int i = 0; i < nums.length; i++) {
                builder += Integer.toString(nums[i]);
            }
            return builder;
        }
        //**************************************************************//

    }

    public static boolean toSwap(int n1, int n2) {
         return Long.parseLong(String.valueOf(n1) + n2) < Long.parseLong(String.valueOf(n2) + n1);
    }

}
