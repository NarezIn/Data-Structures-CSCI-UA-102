package lab7;

import java.io.*;
import java.util.*;
 
class LargestNumber {

      // Main Method
    public static void main(String[] args)
    {
        int[] input1 = {3, 30, 34, 5, 9};
        int[] input2 = {10, 2};

        String answer1;
        String answer2;

        answer1 = Solution.solution(input1);
        answer2 = Solution.solution(input2);

        System.out.println("answer1: " + answer1); // Expected output: 9534330
        System.out.println("answer2: " + answer2); // Expected output: 210
    }
}
