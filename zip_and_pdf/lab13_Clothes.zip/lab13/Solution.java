package lab13;

import java.io.*;
import java.util.*;
 
public class Solution {

    public static int solution(String[][] clothes) {

        //******************** Write your code here ********************//
        int answer = 1;
        Map<String, Integer> map = new HashMap<>();

        /*Put category in the map if non-exist.
          If exist, plus 1.*/
        for(String[] pair : clothes){
            map.put(pair[1], map.getOrDefault(pair[1], 1) + 1);
        }

        for(String key : map.keySet()){
            answer *= map.get(key);
        }

        return answer - 1;
        //******************** Write your code here ********************//
    }
}
