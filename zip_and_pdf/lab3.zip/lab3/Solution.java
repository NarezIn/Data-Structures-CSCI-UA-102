package lab3;

import java.io.*;
import java.util.*;
 
public class Solution {

    public static int solution(int num) {

        //******************** Write your code here ********************//
        if(num == 0){
            return 1;
        }
        return num * solution(num - 1);
        //******************** Write your code here ********************//

    }               

}
