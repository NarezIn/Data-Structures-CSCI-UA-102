package lab7;

import java.io.*;
import java.util.*;
 
class HIndex {

      // Main Method
    public static void main(String[] args)
    {
        int[] input1 = {3, 0, 6, 1, 5};

        int answer1;
        
        answer1 = Solution.solution(input1);

        System.out.println(answer1); // expected output: '3'
    }
}
