package lab7;

import java.io.*;
import java.util.*;
 
public class Solution {

    public static int solution(int[] citations) {

        //******************** Write your code here ********************//
        int answer = 0, c;
        Arrays.sort(citations);
        for(int i = 0; i < citations.length; i++){
            c = citations.length - i;
            if(citations[i] >= c){
                answer = c;
                break;
            }
        }
        return answer;
        //**************************************************************//
    }


}
