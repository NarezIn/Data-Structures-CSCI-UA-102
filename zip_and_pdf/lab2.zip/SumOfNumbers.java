package lab2;
//do not change the name of the package
//the autograder will fail, if the package is not named properly
// add your own name below:
//
// author: Simon Ni
// 

public class SumOfNumbers {
		/*
		Implement this function. Do not change
		anything else in this file.
		*/ 
		public static int sumOfNumbers (String str){
			if(str == null){
				return 0;
			}
			boolean hasNum = false, preIsNum = false;
			int currentNum = 0, sum = 0;
			char[] arr = str.toCharArray();

			for(int i = 0; i < arr.length; i++){
				if(Character.isDigit(arr[i])){
					hasNum = true;
					if(preIsNum){
						currentNum = currentNum * 10 + Integer.parseInt(String.valueOf(arr[i]));
					}
					else{
						currentNum = Integer.parseInt(String.valueOf(arr[i]));
					}
					preIsNum = true;
				}
				else{
					sum += currentNum;
					currentNum = 0;
					preIsNum = false;
				}
			}

			if(currentNum != 0){
				sum += currentNum;
			}
			
			if(hasNum){
				return sum;
			}
			return 0;
		}
}
