package lab5;

import java.io.*;
import java.util.*;
 
public class Solution {

    public static int[] solution(int[] temperatures){
        //******************** Write your code here ********************//
        int[] numDays = new int[temperatures.length];
        Stack<Integer> stk = new Stack<>();
        Stack<Integer> stkPosi = new Stack<>();
        int accum;
        for(int i = 0; i < temperatures.length; i++){
            if(stk.isEmpty() || temperatures[i] <= stk.peek()){
                stk.push(temperatures[i]);
                stkPosi.push(i);
            }
            else{
                while(!stk.isEmpty() && temperatures[i] > stk.peek()){
                    numDays[stkPosi.peek()] = i - stkPosi.peek();
                    stk.pop();
                    stkPosi.pop();
                }
                stk.push(temperatures[i]);
                stkPosi.push(i);
            }
        }
        return numDays;
        //******************** Write your code here ********************//
    }


}
