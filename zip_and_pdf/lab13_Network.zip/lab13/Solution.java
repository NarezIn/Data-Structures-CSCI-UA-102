package lab13;

import java.io.*;
import java.util.*;
 
public class Solution {

    public int solution(int n, int[][] computers) {

        //******************** Write your code here ********************//
        /*       1, 2, 3
             1 [[1, 1, 0],
             2  [1, 1, 0],
             3  [0, 0, 1]]*/
        boolean[] visited = new boolean[computers.length];
        int answer = 0;

        for(int i = 0; i < computers.length; i++){
            if(!visited[i]){
                DFS(computers, i, visited);
                answer++;
            }
        }
        return answer;
        //******************** Write your code here ********************//

    }

    public void DFS(int[][] computers, int i, boolean[] visited){
        visited[i] = true;
        for(int j = 0; j < computers[i].length; j++){
            if(i != j && computers[i][j] == 1 && !visited[j]){
                DFS(computers, j, visited);
            }
        }
    }
}
