package lab4;

import java.util.List;
import java.util.ArrayList;
 
public class Solution {
    public static int[] solution(int[] arr) {
        //******************** Write your code here ********************//
        int prev = arr[0];
        ArrayList<Integer> list = new ArrayList<>();
        list.add(prev);
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] == prev){
                continue;
            }
            else{
                list.add(arr[i]);
            }
            prev = arr[i];
        }
        int[] result = new int[list.size()];
        for (int i = 0; i < list.size(); i++) {
            result[i] = list.get(i);
        }
        return result;
        //******************** Write your code here ********************//
    }

}
