package lab5;

import java.io.*;
import java.util.*;
 
public class Solution {
    public static ArrayList solution(int[] progresses, int[] speeds){
        ArrayList<Integer> answer = new ArrayList<Integer>();
        Queue<Integer> queue = new LinkedList<Integer>();
        //******************** Write your code here ********************//
        for(int j = 0; j < progresses.length; j++){
            queue.offer((int)Math.ceil((100.0 - progresses[j]) / speeds[j]));
        }
        int accum = 1;
        int regWin = !queue.isEmpty() ? queue.poll() : 0;
        while(!queue.isEmpty()){
            if(queue.peek() <= regWin){
                accum++;
                queue.poll();
            }
            else{ //regWin < queue.peek()
                answer.add(accum);
                accum = 1;
                regWin = queue.poll();
            }
        }
        if(accum != 0){
            answer.add(accum);
        }
        //**************************************************************//
        return answer;
    }
}
