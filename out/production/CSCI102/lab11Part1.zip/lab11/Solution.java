package lab11;

import java.io.*;
import java.util.*;
 
public class Solution {

	static int K;
	static int[] arr;
	static StringBuffer[] ans;

    public static StringBuffer[] solution(int input1, int[] input2){
        
        K = input1;
        arr = input2;
        ans = new StringBuffer[K];

		for (int i = 0; i < K; i++)
			ans[i] = new StringBuffer();

        //******************** Write your code here ********************//
		// 1. You can add additional functions to the Solution class to solve the problem
		// 2. However, these functions must be called specifically by the solution() function
		// 3. Also, the final answer should be stored in the variable ans and returned.
        int floor = 0;
        solve(0, input2.length - 1, floor);
        //**************************************************************//
        return ans;
    }

    public static void solve(int s, int e, int f){
        if(f == K || s > e){
            return;
        }
        int mid = (s + e) / 2;
        ans[f].append(arr[mid] + " ");
        solve(s, mid - 1, f + 1);
        solve(mid + 1, e, f + 1);
    }
}
