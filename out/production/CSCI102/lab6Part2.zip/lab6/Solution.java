package lab6;

import java.io.*;
import java.util.*;
 
public class Solution {

    public static Queue<Integer> solution(int n){
        Queue<Integer> cards = new LinkedList<Integer>();
        Queue<Integer> discard = new LinkedList<Integer>();
        //******************** Write your code here ********************//
        //read the data into the queue.
        for(int i = 1; i < n + 1; i++){
            cards.offer(i);
        }

        while(cards.size() > 1){
            //discard first card.
            discard.offer(cards.poll());
            //put the second one at the bottom
            cards.offer(cards.poll());
        }
        //deal with the remaining card
        discard.offer(cards.poll());
        //**************************************************************//
        return discard;
    }
}
