package lab11;

import java.io.*;
import java.util.*;
 
public class Solution {

    public static int solution(int input1){
        
        //******************** Write your code here ********************//
        int height = 1;
        int N_h_minus_2 = 1; // N(0)
        int N_h_minus_1 = 2; // N(1)
        int N_h = 2;
        int N_h_current;

        while (N_h <= input1) {
            height++;
            N_h_current = N_h_minus_1 + N_h_minus_2 + 1;
            // Update values for the next iteration
            N_h_minus_2 = N_h_minus_1;
            N_h_minus_1 = N_h_current;
            N_h = N_h_current;
        }
        return height;
        //**************************************************************//


    }

}
