package lab9;

import java.io.*;
import java.util.*;
 
public class Solution {

    public static int[] solution(String[] operations){
        
        //******************** Write your code here ********************//
        PriorityQueue<Integer> maxhp = new PriorityQueue<>(Collections.reverseOrder());
        PriorityQueue<Integer> minhp = new PriorityQueue<>();
        String[] ops;
        int thing;
        for(int i = 0; i < operations.length; i++){
            ops = operations[i].split(" ");
            if(ops[0].equals("I")){
                maxhp.add(Integer.parseInt(ops[1]));
                minhp.add(Integer.parseInt(ops[1]));
            }
            else if (ops[0].equals("D") && !maxhp.isEmpty() && !minhp.isEmpty()){
                if(ops[1].equals("-1")){
                    thing = minhp.poll();
                    maxhp.remove(thing);
                }
                else{
                    thing = maxhp.poll();
                    minhp.remove(thing);
                }
            }
        }
        if(maxhp.isEmpty() && minhp.isEmpty()){
            return new int[]{0, 0};
        }
        return new int[]{maxhp.peek(), minhp.peek()};
        //**************************************************************//

    }

}
