package lab12;

import java.io.*;
import java.util.*;
 
public class Solution {

    public static String solution(String[] input1, String[] input2){
        
        //******************** Write your code here ********************//
        Map<String, Integer> map = new HashMap<>();
        for(String key : input1){
            map.put(key, map.getOrDefault(key, 0) + 1);
        }
        for (String key : input2){
            map.put(key, map.get(key) - 1);
        }
        for(String key : map.keySet()){
            if(map.get(key) == 1){
                return key;
            }
        }
        return "Yellow";
		//**************************************************************//

    }

}
