package lab10;

import java.io.*;
import java.util.*;
 
public class Solution {

    public static List<Integer> solution(int[] input){
        
        List<Integer> output = new ArrayList<>();
        //******************** Write your code here ********************//
        postOrder(output, input, 0, input.length - 1);
        //**************************************************************//
        return output;
    }

    public static void postOrder(List<Integer> out, int[] input, int start, int end){
        if(start > end){
            return; //or return null???
        }
        int currRoot = input[start];
        int leftSubIndex = start; //end of left sub tree
        int rightSubIndex = start + 1; //start of right sub tree;
        for(int i = start + 1; i <= end; i++){
            if(input[i] > currRoot){
                leftSubIndex = i - 1;
                rightSubIndex = i;
                break;
            }
        }
        postOrder(out, input, start + 1, leftSubIndex);
        postOrder(out, input, rightSubIndex, end);
        out.add(currRoot);
    }

}
