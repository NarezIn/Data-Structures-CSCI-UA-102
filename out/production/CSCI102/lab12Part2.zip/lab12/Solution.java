package lab12;

import java.io.*;
import java.util.*;
 
public class Solution {

    public static boolean solution(String[] input1){
        
        //******************** Write your code here ********************//
        Map<String, Integer> map = new HashMap<>();
        for(int i = 0; i < input1.length; i++){
            map.put(input1[i], 1);
        }
        for (String key : input1){
            for(int j = 0; j < key.toCharArray().length; j++){
                if(map.containsKey(key.substring(0, j))){
                    return false;
                }
            }
        }
        return true;
        //**************************************************************//
    }

}
