 package lab6;

import java.io.*;
import java.util.*;
 
public class Solution {

    public static boolean solution(String A){
        //******************** Write your code here ********************//
        Stack<Character> stk = new Stack<>();
        Queue<Character> que = new LinkedList<>();
        char[] arr = A.toCharArray();

        for(int i = 0; i < arr.length; i++){
            que.offer(arr[i]);
            stk.push(arr[i]);
        }

        for(int j = 0; j < arr.length; j++){
            if(que.poll() != stk.pop()){
                return false;
            }
        }
        return true;
        //**************************************************************//
    }

}
